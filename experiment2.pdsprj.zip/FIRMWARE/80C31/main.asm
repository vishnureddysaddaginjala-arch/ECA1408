;====================================================================
; ORG 0000H
 UP: SETB P2.0
 ACALL DELAY
 CLR P2.0
 ACALL DELAY
 SJMP UP
DELAY: MOV R4,#35
 H1:MOV R3,#255
 H2:DJNZ R3,H2
 DJNZ R4,H1
 RET
 END